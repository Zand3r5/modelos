class TarjetaSube {
    
}

module.exports = TarjetaSube;